﻿namespace Abp.AspNetCore.Mvc.UI.Theme.AdminLTE.Bundling
{
    public static class AdminLTEThemeBundles
    {
        public static class Styles
        {
            public const string Global = "AdminLTE.Global";
        }

        public static class Scripts
        {
            public const string Global = "AdminLTE.Global";
        }
    }
}

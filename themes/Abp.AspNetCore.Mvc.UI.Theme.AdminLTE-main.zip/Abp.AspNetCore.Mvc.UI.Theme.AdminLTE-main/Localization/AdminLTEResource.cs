﻿using Volo.Abp.Localization;

namespace Abp.AspNetCore.Mvc.UI.Theme.AdminLTE.Localization
{
    [LocalizationResourceName("AdminLTE")]
    public class AdminLTEResource
    {
    }
}
